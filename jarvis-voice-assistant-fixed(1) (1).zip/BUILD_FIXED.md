# JARVIS Voice Assistant — fixed build configuration

This copy fixes the CI build configuration that was failing before.

Changes:
- Uses Android Gradle Plugin 9.1.1 with Gradle 9.3.1.
- Uses the standard Android 36 compile SDK instead of requiring API 36.1.
- Adds a GitHub Actions workflow that installs Gradle 9.3.1 directly, so a `gradlew` file is not required.

## GitHub
Upload/push the project to the repository, then open **Actions → Build JARVIS APK**.
The generated debug APK is uploaded as the `JARVIS-debug-APK` artifact.

## Android Studio
Open the extracted folder as an Android project. Use JDK 17 and let Android Studio sync the Gradle project.
