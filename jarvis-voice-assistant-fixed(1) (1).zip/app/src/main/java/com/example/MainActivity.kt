package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.JarvisViewModel
import com.example.ui.JarvisViewModelFactory
import com.example.ui.screens.MainScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.SpeechAndTtsManager

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: JarvisViewModel
    private var speechAndTtsManager: SpeechAndTtsManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val factory = JarvisViewModelFactory(application)
        viewModel = ViewModelProvider(this, factory)[JarvisViewModel::class.java]

        speechAndTtsManager = SpeechAndTtsManager(
            context = this,
            onVoiceResult = { spokenText ->
                viewModel.processUserInput(spokenText, isVoiceInput = true)
            }
        )

        viewModel.initSpeechManager(speechAndTtsManager!!)

        setContent {
            MyApplicationTheme {
                val navController = rememberNavController()

                NavHost(navController = navController, startDestination = "main") {
                    composable("main") {
                        MainScreen(
                            viewModel = viewModel,
                            onOpenSettings = { navController.navigate("settings") }
                        )
                    }
                    composable("settings") {
                        SettingsScreen(
                            viewModel = viewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechAndTtsManager?.destroy()
    }
}
