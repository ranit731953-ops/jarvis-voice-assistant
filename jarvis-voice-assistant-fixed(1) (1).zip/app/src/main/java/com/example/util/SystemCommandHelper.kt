package com.example.util

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class CommandExecutionResult {
    data class Executed(val actionName: String, val confirmationMessage: String) : CommandExecutionResult()
    data class NotACommand(val text: String) : CommandExecutionResult()
    data class Failed(val error: String) : CommandExecutionResult()
}

class SystemCommandHelper(private val context: Context) {

    fun executeOrParseCommand(input: String): CommandExecutionResult {
        val lower = input.lowercase(Locale.ROOT).trim()

        return when {
            lower.contains("open settings") || lower == "settings" -> {
                openSettings()
            }
            lower.contains("open calculator") || lower == "calculator" -> {
                openCalculator()
            }
            lower.contains("open camera") || lower == "camera" -> {
                openCamera()
            }
            lower.contains("open dialer") || lower.contains("open phone") || lower.startsWith("call ") -> {
                val number = if (lower.startsWith("call ")) lower.removePrefix("call ").trim() else ""
                openDialer(number)
            }
            lower.contains("open browser") || lower.startsWith("search ") || lower.startsWith("google ") -> {
                val query = when {
                    lower.startsWith("search ") -> lower.removePrefix("search ").trim()
                    lower.startsWith("google ") -> lower.removePrefix("google ").trim()
                    else -> ""
                }
                openBrowser(query)
            }
            lower.contains("check battery") || lower.contains("battery status") || lower.contains("battery percentage") || lower.contains("how much battery") -> {
                val batteryInfo = getBatteryStatus()
                CommandExecutionResult.Executed("Battery Diagnostic", batteryInfo)
            }
            lower.contains("what time") || lower.contains("current time") || lower.contains("what is the time") || lower.contains("check time") -> {
                val timeStr = getCurrentTimeString()
                CommandExecutionResult.Executed("Clock Check", "The current time is $timeStr, Sir.")
            }
            else -> CommandExecutionResult.NotACommand(input)
        }
    }

    fun openSettings(): CommandExecutionResult {
        return try {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            CommandExecutionResult.Executed("System Settings", "Opening device settings menu, Sir.")
        } catch (e: Exception) {
            CommandExecutionResult.Failed("Could not launch Settings: ${e.localizedMessage}")
        }
    }

    fun openCalculator(): CommandExecutionResult {
        val intents = listOf(
            Intent().apply { setClassName("com.google.android.calculator", "com.android.calculator2.Calculator") },
            Intent().apply { setClassName("com.android.calculator2", "com.android.calculator2.Calculator") },
            Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_APP_CALCULATOR) }
        )

        for (intent in intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return CommandExecutionResult.Executed("Calculator App", "Opening calculator interface, Sir.")
            } catch (_: Exception) {
            }
        }

        // Fallback: search browser for online calculator
        return openBrowser("online calculator")
    }

    fun openCamera(): CommandExecutionResult {
        return try {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            CommandExecutionResult.Executed("Camera", "Activating camera sensors, Sir.")
        } catch (e: Exception) {
            CommandExecutionResult.Failed("Could not open camera: ${e.localizedMessage}")
        }
    }

    fun openDialer(phoneNumber: String = ""): CommandExecutionResult {
        return try {
            val intent = if (phoneNumber.isNotBlank()) {
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
            } else {
                Intent(Intent.ACTION_DIAL)
            }.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val msg = if (phoneNumber.isNotBlank()) "Opening dialer with $phoneNumber..." else "Opening phone dialer, Sir."
            CommandExecutionResult.Executed("Phone Dialer", msg)
        } catch (e: Exception) {
            CommandExecutionResult.Failed("Could not launch phone dialer: ${e.localizedMessage}")
        }
    }

    fun openBrowser(query: String = ""): CommandExecutionResult {
        return try {
            val uri = if (query.isNotBlank()) {
                Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
            } else {
                Uri.parse("https://www.google.com")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val msg = if (query.isNotBlank()) "Searching web for '$query'..." else "Opening web browser, Sir."
            CommandExecutionResult.Executed("Web Browser", msg)
        } catch (e: Exception) {
            CommandExecutionResult.Failed("Could not launch browser: ${e.localizedMessage}")
        }
    }

    fun getBatteryStatus(): String {
        return try {
            val batteryStatusIntent = context.registerReceiver(
                null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
            val level = batteryStatusIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatusIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = batteryStatusIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1

            val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale.toFloat()).toInt() else 0
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

            val statusStr = if (isCharging) "plugged in and charging" else "discharging on internal power"
            "Power Diagnostics: Battery is currently at $batteryPct%, $statusStr, Sir."
        } catch (e: Exception) {
            "Power status unknown: ${e.localizedMessage}"
        }
    }

    fun getCurrentTimeString(): String {
        val sdf = SimpleDateFormat("EEEE, MMMM d, yyyy 'at' hh:mm a", Locale.getDefault())
        return sdf.format(Date())
    }
}
