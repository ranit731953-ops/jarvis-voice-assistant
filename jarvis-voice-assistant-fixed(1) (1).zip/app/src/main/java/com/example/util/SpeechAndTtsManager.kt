package com.example.util

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.Locale

sealed class VoiceState {
    object Idle : VoiceState()
    object Listening : VoiceState()
    data class Processing(val recognizedText: String) : VoiceState()
    data class Speaking(val text: String) : VoiceState()
    data class Error(val message: String) : VoiceState()
}

enum class ReplayStatus {
    READY,
    PLAYING,
    ERROR
}

data class ReplayState(
    val messageId: Long = -1L,
    val status: ReplayStatus = ReplayStatus.READY
)

class SpeechAndTtsManager(
    private val context: Context,
    private val onVoiceResult: (String) -> Unit
) : TextToSpeech.OnInitListener, RecognitionListener {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var webView: WebView? = null
    private var nativeTts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _replayState = MutableStateFlow(ReplayState())
    val replayState: StateFlow<ReplayState> = _replayState.asStateFlow()

    private var isNativeTtsReady = false
    private var isWebViewReady = false
    private var replayingMessageId: Long? = null
    private var pendingReplayText: String? = null

    init {
        // Initialize Web Speech API WebView engine on Main thread
        mainHandler.post {
            try {
                val wv = WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.domStorageEnabled = true

                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                            consoleMessage?.let {
                                Log.d("JARVIS", it.message())
                            }
                            return true
                        }
                    }

                    addJavascriptInterface(object {
                        @JavascriptInterface
                        fun onEngineReady() {
                            mainHandler.post {
                                isWebViewReady = true
                                Log.d("JARVIS", "[JARVIS] WebSpeech Engine initialized")
                            }
                        }

                        @JavascriptInterface
                        fun onTtsStart(msgId: Long) {
                            mainHandler.post {
                                Log.d("JARVIS", "[REPLAY] TTS_STARTED")
                                _replayState.value = ReplayState(msgId, ReplayStatus.PLAYING)
                                _voiceState.value = VoiceState.Speaking("PLAYING...")
                            }
                        }

                        @JavascriptInterface
                        fun onTtsEnd(msgId: Long) {
                            mainHandler.post {
                                Log.d("JARVIS", "[REPLAY] TTS_ENDED")
                                _replayState.value = ReplayState(msgId, ReplayStatus.READY)
                                replayingMessageId = null
                                _voiceState.value = VoiceState.Idle
                            }
                        }

                        @JavascriptInterface
                        fun onTtsError(msgId: Long, errorStr: String) {
                            mainHandler.post {
                                Log.e("JARVIS", "[REPLAY] TTS_ERROR: $errorStr")
                                _replayState.value = ReplayState(msgId, ReplayStatus.ERROR)
                                replayingMessageId = null
                                _voiceState.value = VoiceState.Idle
                            }
                        }

                        @JavascriptInterface
                        fun onTtsUnavailable() {
                            mainHandler.post {
                                Log.e("JARVIS", "[REPLAY] TTS_ERROR: speechSynthesis unavailable")
                                _replayState.value = ReplayState(-1L, ReplayStatus.ERROR)
                                _voiceState.value = VoiceState.Error("Web Speech API (speechSynthesis) is unavailable.")
                            }
                        }
                    }, "AndroidBridge")

                    val htmlContent = """
                        <!DOCTYPE html>
                        <html>
                        <head>
                        <script>
                        console.log('[JARVIS] WebSpeech Engine initialized');
                        if (window.AndroidBridge) window.AndroidBridge.onEngineReady();

                        if ('speechSynthesis' in window) {
                            window.speechSynthesis.onvoiceschanged = function() {
                                window.speechSynthesis.getVoices();
                            };
                        }

                        window.speakText = function(msgId, text) {
                            console.log('[REPLAY] BUTTON_CLICKED');
                            if (!('speechSynthesis' in window)) {
                                console.log('[REPLAY] TTS_ERROR');
                                if (window.AndroidBridge) window.AndroidBridge.onTtsUnavailable();
                                return;
                            }
                            try {
                                window.speechSynthesis.cancel();
                                const utterance = new SpeechSynthesisUtterance(text);
                                utterance.lang = 'en-US';
                                utterance.rate = 1.0;
                                utterance.pitch = 1.0;

                                utterance.onstart = function() {
                                    console.log('[REPLAY] TTS_STARTED');
                                    if (window.AndroidBridge) window.AndroidBridge.onTtsStart(msgId);
                                };

                                utterance.onend = function() {
                                    console.log('[REPLAY] TTS_ENDED');
                                    if (window.AndroidBridge) window.AndroidBridge.onTtsEnd(msgId);
                                };

                                utterance.onerror = function(e) {
                                    console.log('[REPLAY] TTS_ERROR');
                                    if (window.AndroidBridge) window.AndroidBridge.onTtsError(msgId, (e && e.error) ? e.error : 'TTS error');
                                };

                                window.speechSynthesis.speak(utterance);
                            } catch(err) {
                                console.log('[REPLAY] TTS_ERROR');
                                if (window.AndroidBridge) window.AndroidBridge.onTtsError(msgId, err ? err.message : 'Exception');
                            }
                        };

                        window.stopText = function() {
                            if ('speechSynthesis' in window) {
                                try {
                                    window.speechSynthesis.cancel();
                                } catch(e) {}
                            }
                        };
                        </script>
                        </head>
                        <body></body>
                        </html>
                    """.trimIndent()

                    loadDataWithBaseURL("https://localhost", htmlContent, "text/html", "UTF-8", null)
                }
                webView = wv
            } catch (e: Exception) {
                Log.e("JARVIS", "TTS_ERROR: Failed to initialize WebView for Web Speech API: ${e.localizedMessage}")
            }
        }

        // Initialize Native Android TextToSpeech as fallback
        try {
            nativeTts = TextToSpeech(context, this)
        } catch (e: Exception) {
            Log.e("JARVIS", "Native TextToSpeech exception: ${e.localizedMessage}")
        }

        initSpeechRecognizer()
    }

    private fun initSpeechRecognizer() {
        try {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(this@SpeechAndTtsManager)
                }
            } else {
                Log.w("JARVIS", "Speech recognition is not available on this device")
            }
        } catch (e: Exception) {
            Log.e("JARVIS", "Failed to create SpeechRecognizer: ${e.localizedMessage}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = nativeTts?.setLanguage(Locale.US)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isNativeTtsReady = true
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                nativeTts?.setAudioAttributes(audioAttributes)
            }
        }
    }

    fun isSpeechAvailable(): Boolean {
        val avail = SpeechRecognizer.isRecognitionAvailable(context)
        Log.d("JARVIS", "SpeechRecognition check completed: available=$avail")
        return avail
    }

    fun startListening() {
        Log.d("JARVIS", "MIC BUTTON CLICKED")
        Log.d("JARVIS", "microphone started")

        try {
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            Log.e("JARVIS", "error cancelling previous recognition instance: ${e.localizedMessage}")
        }

        if (speechRecognizer == null) {
            initSpeechRecognizer()
        }
        stopSpeaking()

        if (speechRecognizer == null || !SpeechRecognizer.isRecognitionAvailable(context)) {
            val err = "Speech recognition service unavailable on this device."
            Log.e("JARVIS", "error: $err")
            _voiceState.value = VoiceState.Error(err)
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS is listening...")
        }
        try {
            _voiceState.value = VoiceState.Listening
            Log.d("JARVIS", "SPEECH RECOGNITION STARTED")
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            val err = "Speech recognition failed: ${e.localizedMessage}"
            Log.e("JARVIS", "error: $err", e)
            _voiceState.value = VoiceState.Error(err)
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.e("JARVIS", "error stopping listening: ${e.localizedMessage}")
        }
        if (_voiceState.value is VoiceState.Listening) {
            _voiceState.value = VoiceState.Idle
        }
    }

    fun replayMessage(messageId: Long, text: String, rate: Float = 1.0f, pitch: Float = 0.95f) {
        Log.d("JARVIS", "[REPLAY] BUTTON_CLICKED")

        if (text.isBlank()) {
            Log.e("JARVIS", "[REPLAY] TTS_ERROR: Empty text provided for replay")
            _replayState.value = ReplayState(messageId, ReplayStatus.ERROR)
            return
        }

        // Toggle Stop if currently replaying this message
        if (replayingMessageId == messageId && _replayState.value.status == ReplayStatus.PLAYING) {
            Log.d("JARVIS", "Stopping current playback for message $messageId")
            stopSpeaking()
            _replayState.value = ReplayState(messageId, ReplayStatus.READY)
            replayingMessageId = null
            return
        }

        stopSpeaking()
        replayingMessageId = messageId
        _replayState.value = ReplayState(messageId, ReplayStatus.PLAYING)

        mainHandler.post {
            val quotedText = JSONObject.quote(text)
            val jsCall = "window.speakText($messageId, $quotedText);"
            webView?.evaluateJavascript(jsCall) { result ->
                if (result == null || result == "null") {
                    Log.d("JARVIS", "Evaluated WebView TTS JS call for message $messageId")
                }
            }
        }

        try {
            if (isNativeTtsReady && nativeTts != null) {
                nativeTts?.setSpeechRate(rate)
                nativeTts?.setPitch(pitch)
                val utteranceId = "REPLAY_UTTERANCE_$messageId"
                nativeTts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
            }
        } catch (e: Exception) {
            Log.e("JARVIS", "Native TTS fallback error: ${e.localizedMessage}")
        }
    }

    fun speak(text: String, rate: Float = 1.0f, pitch: Float = 0.95f) {
        if (text.isBlank()) return
        replayMessage(-1L, text, rate, pitch)
    }

    fun stopSpeaking() {
        mainHandler.post {
            webView?.evaluateJavascript("window.stopText();", null)
        }
        try {
            if (nativeTts?.isSpeaking == true) {
                nativeTts?.stop()
            }
        } catch (e: Exception) {
            Log.e("JARVIS", "error stopping native TTS: ${e.localizedMessage}")
        }
        if (replayingMessageId != null) {
            val oldId = replayingMessageId ?: -1L
            replayingMessageId = null
            _replayState.value = ReplayState(oldId, ReplayStatus.READY)
        }
        if (_voiceState.value is VoiceState.Speaking) {
            _voiceState.value = VoiceState.Idle
        }
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
            nativeTts?.stop()
            nativeTts?.shutdown()
            nativeTts = null
            mainHandler.post {
                webView?.destroy()
                webView = null
            }
        } catch (e: Exception) {
            Log.e("JARVIS", "error destroying speech components: ${e.localizedMessage}")
        }
    }

    // RecognitionListener Callbacks
    override fun onReadyForSpeech(params: Bundle?) {
        Log.d("JARVIS", "speech recognition started")
        _voiceState.value = VoiceState.Listening
    }

    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}

    override fun onError(error: Int) {
        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            Log.d("JARVIS", "Speech recognition idle: no speech input detected (code $error)")
            _voiceState.value = VoiceState.Idle
            return
        }

        val message = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
            SpeechRecognizer.ERROR_CLIENT -> "Client error"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
            SpeechRecognizer.ERROR_NETWORK -> "Network error"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer busy"
            else -> "Speech recognition error ($error)"
        }
        Log.e("JARVIS", "error: speech recognition error: $message (code $error)")
        _voiceState.value = VoiceState.Error(message)
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val spokenText = matches[0]
            Log.d("JARVIS", "transcript received: '$spokenText'")
            _voiceState.value = VoiceState.Processing(spokenText)
            onVoiceResult(spokenText)
        } else {
            Log.w("JARVIS", "error: no matches found in speech results")
            _voiceState.value = VoiceState.Idle
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}



