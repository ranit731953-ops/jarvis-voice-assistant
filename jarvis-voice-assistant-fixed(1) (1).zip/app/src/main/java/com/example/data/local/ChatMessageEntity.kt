package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MessageSender {
    USER,
    JARVIS,
    SYSTEM
}

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isVoiceMessage: Boolean = false,
    val executedCommand: String? = null
)
