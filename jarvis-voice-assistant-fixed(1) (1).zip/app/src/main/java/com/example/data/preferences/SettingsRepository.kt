package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "jarvis_settings")

class SettingsRepository(private val context: Context) {

    companion object {
        val KEY_CUSTOM_API_KEY = stringPreferencesKey("custom_api_key")
        val KEY_AUTO_SPEAK = booleanPreferencesKey("auto_speak_response")
        val KEY_SPEECH_RATE = floatPreferencesKey("speech_rate")
        val KEY_SPEECH_PITCH = floatPreferencesKey("speech_pitch")
        val KEY_SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
        val KEY_INITIAL_GREETING_SEEDED = booleanPreferencesKey("initial_greeting_seeded")
    }

    val initialGreetingSeeded: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_INITIAL_GREETING_SEEDED] ?: false
    }

    suspend fun setInitialGreetingSeeded(seeded: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_INITIAL_GREETING_SEEDED] = seeded
        }
    }

    val customApiKey: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_CUSTOM_API_KEY] ?: ""
    }

    val autoSpeak: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_AUTO_SPEAK] ?: true
    }

    val speechRate: Flow<Float> = context.dataStore.data.map { preferences ->
        preferences[KEY_SPEECH_RATE] ?: 1.0f
    }

    val speechPitch: Flow<Float> = context.dataStore.data.map { preferences ->
        preferences[KEY_SPEECH_PITCH] ?: 0.95f
    }

    val systemPrompt: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_SYSTEM_PROMPT] ?: DEFAULT_SYSTEM_PROMPT
    }

    suspend fun setCustomApiKey(key: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_CUSTOM_API_KEY] = key
        }
    }

    suspend fun setAutoSpeak(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_AUTO_SPEAK] = enabled
        }
    }

    suspend fun setSpeechRate(rate: Float) {
        context.dataStore.edit { preferences ->
            preferences[KEY_SPEECH_RATE] = rate
        }
    }

    suspend fun setSpeechPitch(pitch: Float) {
        context.dataStore.edit { preferences ->
            preferences[KEY_SPEECH_PITCH] = pitch
        }
    }

    suspend fun setSystemPrompt(prompt: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_SYSTEM_PROMPT] = prompt
        }
    }
}

val DEFAULT_SYSTEM_PROMPT = """
You are JARVIS (Just A Rather Very Intelligent System), an advanced AI assistant created to assist Sir/Ma'am.
Respond with high intelligence, refined politeness, subtle wit, and concise clarity.
You can execute basic device system commands when requested. If the user asks you to open settings, browser, calculator, camera, dialer, or check battery status, state clearly what action you are taking or confirm execution.
""".trimIndent()
