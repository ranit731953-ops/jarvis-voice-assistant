package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import com.example.data.local.ChatMessageEntity
import com.example.data.local.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class GeminiResult {
    data class Success(val responseText: String) : GeminiResult()
    data class Error(val message: String) : GeminiResult()
}

class GeminiRepository {

    suspend fun generateReply(
        history: List<ChatMessageEntity>,
        userMessage: String,
        customApiKey: String?,
        systemPrompt: String,
        model: String = "gemini-1.5-flash"
    ): GeminiResult = withContext(Dispatchers.IO) {
        val apiKey = when {
            !customApiKey.isNullOrBlank() -> customApiKey.trim()
            !BuildConfig.GEMINI_API_KEY.isNullOrBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY" -> BuildConfig.GEMINI_API_KEY
            else -> ""
        }

        Log.d("JARVIS_LOG", "Gemini request started for query: '$userMessage' using model: '$model'")

        if (apiKey.isBlank()) {
            Log.w("JARVIS_LOG", "No API key configured. Utilizing local intelligent response core.")
            val lower = userMessage.lowercase().trim()
            val fallbackReply = when {
                lower.contains("hello") || lower.contains("hi") || lower.contains("hey") ->
                    "Greetings, Sir. J.A.R.V.I.S. core is operating online. How may I assist you today?"
                lower.contains("who are you") || lower.contains("your name") ->
                    "I am J.A.R.V.I.S., Just A Rather Very Intelligent System. Ready to assist."
                lower.contains("what can you do") || lower.contains("help") ->
                    "I can launch system apps (Settings, Camera, Calculator, Phone, Browser), check device diagnostics like battery and time, and respond to voice or text commands."
                lower.contains("how are you") ->
                    "All systems are functioning at peak efficiency, Sir. Thank you for asking."
                else ->
                    "Command received: '$userMessage', Sir. Operating in local core mode. Configure a Gemini API key in Settings for cloud generative AI."
            }
            Log.d("JARVIS_LOG", "Gemini response received (local fallback): '$fallbackReply'")
            return@withContext GeminiResult.Success(fallbackReply)
        }

        val contents = mutableListOf<Content>()
        
        // Exclude the current userMessage if it was already inserted into history to avoid duplicating
        val cleanHistory = history.filter { 
            it.text.isNotBlank() && !(it.sender == MessageSender.USER && it.text == userMessage)
        }.takeLast(8)

        for (msg in cleanHistory) {
            val role = if (msg.sender == MessageSender.USER) "user" else "model"
            if (contents.isEmpty()) {
                if (role == "user") {
                    contents.add(Content(role = "user", parts = listOf(Part(text = msg.text))))
                }
            } else {
                val lastRole = contents.last().role
                if (role != lastRole) {
                    contents.add(Content(role = role, parts = listOf(Part(text = msg.text))))
                } else if (role == "user") {
                    val prevText = contents.last().parts.firstOrNull()?.text ?: ""
                    contents[contents.size - 1] = Content(role = "user", parts = listOf(Part(text = "$prevText\n${msg.text}")))
                }
            }
        }

        // Guarantee final user content
        if (contents.isEmpty() || contents.last().role != "user") {
            contents.add(Content(role = "user", parts = listOf(Part(text = userMessage))))
        } else {
            val prevText = contents.last().parts.firstOrNull()?.text ?: ""
            if (prevText != userMessage) {
                contents[contents.size - 1] = Content(role = "user", parts = listOf(Part(text = "$prevText\n$userMessage")))
            }
        }

        val systemInstruction = Content(
            parts = listOf(Part(text = systemPrompt))
        )

        val request = GenerateContentRequest(
            contents = contents,
            generationConfig = GenerationConfig(
                temperature = 0.7f,
                topP = 0.95f,
                topK = 40
            ),
            systemInstruction = systemInstruction
        )

        try {
            val response = RetrofitClient.geminiService.generateContent(
                model = model,
                apiKey = apiKey,
                request = request
            )
            
            if (response.error != null) {
                val errorMsg = "API Error (${response.error.code}): ${response.error.message}"
                Log.e("JARVIS_LOG", errorMsg)
                return@withContext GeminiResult.Error(errorMsg)
            }

            val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!text.isNullOrBlank()) {
                Log.d("JARVIS_LOG", "Gemini response received: '$text'")
                GeminiResult.Success(text)
            } else {
                Log.e("JARVIS_LOG", "Empty response received from Gemini API.")
                GeminiResult.Error("JARVIS received an empty response from Gemini.")
            }
        } catch (e: Exception) {
            val msg = e.localizedMessage ?: "Network connection failure."
            Log.e("JARVIS_LOG", "Gemini request exception: $msg", e)
            GeminiResult.Error("JARVIS communication error: $msg")
        }
    }

    suspend fun testApiKey(apiKey: String, model: String = "gemini-1.5-flash"): GeminiResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext GeminiResult.Error("Key cannot be empty.")
        }
        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = "Hello JARVIS, system diagnostic test."))))
        )
        try {
            val response = RetrofitClient.geminiService.generateContent(
                model = model,
                apiKey = apiKey.trim(),
                request = request
            )
            if (response.error != null) {
                GeminiResult.Error("Test failed: ${response.error.message}")
            } else {
                val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!text.isNullOrBlank()) {
                    GeminiResult.Success("Key validated successfully. Response: $text")
                } else {
                    GeminiResult.Error("Key validation returned empty content.")
                }
            }
        } catch (e: Exception) {
            GeminiResult.Error("Key test error: ${e.localizedMessage}")
        }
    }
}

