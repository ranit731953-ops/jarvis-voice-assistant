package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChatMessageEntity
import com.example.data.local.MessageSender
import com.example.ui.theme.JarvisCyanAccent
import com.example.ui.theme.JarvisCyanPrimary
import com.example.ui.theme.JarvisGold
import com.example.util.ReplayState
import com.example.util.ReplayStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatMessageList(
    messages: List<ChatMessageEntity>,
    replayState: ReplayState = ReplayState(),
    onReplayMessage: (ChatMessageEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier
    ) {
        items(messages, key = { it.id }) { message ->
            ChatMessageItem(
                message = message,
                replayState = replayState,
                onReplayMessage = onReplayMessage
            )
        }
    }
}

@Composable
fun ChatMessageItem(
    message: ChatMessageEntity,
    replayState: ReplayState = ReplayState(),
    onReplayMessage: (ChatMessageEntity) -> Unit
) {
    val isUser = message.sender == MessageSender.USER
    val timeFormatted = remember(message.timestamp) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp))
    }

    Column(
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
        modifier = Modifier
            .fillMaxWidth()
            .testTag(if (isUser) "user_chat_bubble" else "jarvis_chat_bubble")
    ) {
        // Top label badge (timestamp & role)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 4.dp, start = 4.dp, end = 4.dp)
        ) {
            if (message.isVoiceMessage) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Voice Input",
                    tint = JarvisGold,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
                text = if (isUser) "USER • $timeFormatted" else "J.A.R.V.I.S. • $timeFormatted",
                color = if (isUser) Color.White.copy(alpha = 0.5f) else JarvisCyanPrimary.copy(alpha = 0.7f),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        // Message Bubble Container
        Box(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 2.dp,
                        bottomEnd = if (isUser) 2.dp else 16.dp
                    )
                )
                .background(
                    if (isUser) Color(0xFF0F2238) else Color(0xFF081829)
                )
                .border(
                    width = 1.dp,
                    color = if (isUser) Color(0xFF1E3A5F) else JarvisCyanPrimary.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 2.dp,
                        bottomEnd = if (isUser) 2.dp else 16.dp
                    )
                )
                .padding(14.dp)
        ) {
            Column {
                if (!message.executedCommand.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .padding(bottom = 8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(JarvisGold.copy(alpha = 0.15f))
                            .border(1.dp, JarvisGold.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "COMMAND EXECUTED: ${message.executedCommand}",
                            color = JarvisGold,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    text = message.text,
                    color = if (isUser) Color(0xFFE2F1FF) else JarvisCyanAccent,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                if (!isUser) {
                    val isThisMessageReplaying = replayState.messageId == message.id
                    val isPlayingThisMessage = isThisMessageReplaying && replayState.status == ReplayStatus.PLAYING

                    val statusText = if (isThisMessageReplaying) {
                        when (replayState.status) {
                            ReplayStatus.PLAYING -> "PLAYING..."
                            ReplayStatus.READY -> "READY"
                            ReplayStatus.ERROR -> "TTS ERROR"
                        }
                    } else null

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!statusText.isNullOrBlank()) {
                            Text(
                                text = statusText,
                                color = if (replayState.status == ReplayStatus.ERROR) Color(0xFFFF5252) else JarvisCyanAccent,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                        }
                        IconButton(
                            onClick = {
                                android.util.Log.d("JARVIS", "[REPLAY] BUTTON_CLICKED")
                                onReplayMessage(message)
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("replay_button_${message.id}")
                        ) {
                            Icon(
                                imageVector = if (isPlayingThisMessage) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = if (isPlayingThisMessage) "Stop Audio" else "Replay Audio",
                                tint = if (isPlayingThisMessage) JarvisGold else JarvisCyanPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
