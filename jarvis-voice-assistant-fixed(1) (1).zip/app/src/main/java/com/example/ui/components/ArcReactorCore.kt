package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JarvisCyanAccent
import com.example.ui.theme.JarvisCyanPrimary
import com.example.ui.theme.JarvisGold
import com.example.util.VoiceState

@Composable
fun ArcReactorCore(
    voiceState: VoiceState,
    isLoading: Boolean,
    onMicClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ReactorPulse")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (voiceState is VoiceState.Listening || isLoading) 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val rotationDegrees by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val waveHeight1 by infiniteTransition.animateFloat(
        initialValue = 8f, targetValue = 24f,
        animationSpec = infiniteRepeatable(tween(400, easing = LinearEasing), RepeatMode.Reverse), label = "h1"
    )
    val waveHeight2 by infiniteTransition.animateFloat(
        initialValue = 18f, targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(550, easing = LinearEasing), RepeatMode.Reverse), label = "h2"
    )
    val waveHeight3 by infiniteTransition.animateFloat(
        initialValue = 12f, targetValue = 28f,
        animationSpec = infiniteRepeatable(tween(350, easing = LinearEasing), RepeatMode.Reverse), label = "h3"
    )

    val statusText = when {
        isLoading -> "PROCESSING DATA MATRIX"
        voiceState is VoiceState.Listening -> "LISTENING..."
        voiceState is VoiceState.Speaking -> "JARVIS VOCALIZING"
        voiceState is VoiceState.Processing -> "ANALYZING AUDIO"
        else -> "STANDBY FOR COMMAND"
    }

    val isListeningOrSpeaking = voiceState is VoiceState.Listening || voiceState is VoiceState.Speaking || isLoading

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(200.dp)
        ) {
            // Ambient Cyan Glow Background Blur
            Box(
                modifier = Modifier
                    .size(170.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                JarvisCyanPrimary.copy(alpha = if (isListeningOrSpeaking) 0.35f else 0.15f),
                                Color.Transparent
                            )
                        )
                    )
                    .blur(16.dp)
            )

            // Outer Canvas Rings
            Canvas(modifier = Modifier.size(190.dp)) {
                val center = size / 2f
                val radius = size.minDimension / 2f - 8.dp.toPx()

                // Outer Dashed HUD Ring
                drawCircle(
                    color = JarvisCyanPrimary.copy(alpha = 0.3f),
                    radius = radius,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // Middle Tech Ring
                drawCircle(
                    color = JarvisCyanAccent.copy(alpha = 0.5f),
                    radius = radius - 16.dp.toPx(),
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            // Outer Ring Circle
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .border(2.dp, JarvisCyanPrimary.copy(alpha = 0.3f), CircleShape)
                    .padding(8.dp)
                    .border(1.dp, JarvisCyanAccent.copy(alpha = 0.5f), CircleShape)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                // Inner Radial Gradient Glass Core
                Box(
                    modifier = Modifier
                        .size(128.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF003853),
                                    Color(0xFF031422)
                                )
                            )
                        )
                        .border(1.5.dp, JarvisCyanPrimary.copy(alpha = 0.8f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // Center Mic Button Trigger
                    val interactionSource = remember { MutableInteractionSource() }
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(
                                if (voiceState is VoiceState.Listening) JarvisGold else JarvisCyanPrimary
                            )
                            .clickable(
                                interactionSource = interactionSource,
                                indication = null,
                                onClick = {
                                    android.util.Log.d("JARVIS_LOG", "MIC BUTTON CLICKED")
                                    onMicClick()
                                }
                            )
                            .testTag("arc_reactor_mic_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (voiceState is VoiceState.Listening || voiceState is VoiceState.Speaking) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = "Microphone Core Trigger",
                            tint = Color(0xFF020408),
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Status Header Text
        Text(
            text = statusText,
            color = JarvisCyanPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 2.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Equalizer Bars when active
        if (isListeningOrSpeaking) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.height(28.dp)
            ) {
                val activeBarColor = if (voiceState is VoiceState.Listening) JarvisGold else JarvisCyanPrimary
                Box(modifier = Modifier.width(3.dp).height(waveHeight1.dp).background(activeBarColor, CircleShape))
                Spacer(modifier = Modifier.width(4.dp))
                Box(modifier = Modifier.width(3.dp).height(waveHeight2.dp).background(activeBarColor, CircleShape))
                Spacer(modifier = Modifier.width(4.dp))
                Box(modifier = Modifier.width(3.dp).height(waveHeight3.dp).background(activeBarColor, CircleShape))
                Spacer(modifier = Modifier.width(4.dp))
                Box(modifier = Modifier.width(3.dp).height(waveHeight2.dp).background(activeBarColor, CircleShape))
                Spacer(modifier = Modifier.width(4.dp))
                Box(modifier = Modifier.width(3.dp).height(waveHeight1.dp).background(activeBarColor, CircleShape))
            }
        }
    }
}
