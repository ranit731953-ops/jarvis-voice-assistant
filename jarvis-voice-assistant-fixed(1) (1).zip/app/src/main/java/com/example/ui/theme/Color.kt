package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val JarvisBackground = Color(0xFF070B14)
val JarvisSurface = Color(0xFF0D1527)
val JarvisSurfaceVariant = Color(0xFF14223A)
val JarvisCyanPrimary = Color(0xFF00E5FF)
val JarvisCyanSecondary = Color(0xFF00B0FF)
val JarvisCyanAccent = Color(0xFF80D8FF)
val JarvisGold = Color(0xFFFFD700)

val JarvisUserBubble = Color(0xFF0F2B4A)
val JarvisBotBubble = Color(0xFF0A1B2E)
val JarvisError = Color(0xFFFF5252)

val JarvisOnPrimary = Color(0xFF001A26)
val JarvisOnBackground = Color(0xFFE0F7FA)
val JarvisOnSurface = Color(0xFFE0F7FA)
val JarvisOutline = Color(0xFF00E5FF)

