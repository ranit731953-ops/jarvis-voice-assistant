package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JarvisDarkColorScheme = darkColorScheme(
  primary = JarvisCyanPrimary,
  onPrimary = JarvisOnPrimary,
  secondary = JarvisCyanSecondary,
  onSecondary = Color.White,
  tertiary = JarvisGold,
  background = JarvisBackground,
  onBackground = JarvisOnBackground,
  surface = JarvisSurface,
  onSurface = JarvisOnSurface,
  surfaceVariant = JarvisSurfaceVariant,
  onSurfaceVariant = JarvisOnSurface,
  error = JarvisError,
  outline = JarvisOutline.copy(alpha = 0.5f)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = JarvisDarkColorScheme,
    typography = Typography,
    content = content
  )
}

