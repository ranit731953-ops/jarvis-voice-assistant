package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import com.example.data.local.MessageSender
import com.example.data.preferences.SettingsRepository
import com.example.data.remote.GeminiRepository
import com.example.data.remote.GeminiResult
import com.example.util.CommandExecutionResult
import com.example.util.ReplayState
import com.example.util.ReplayStatus
import com.example.util.SpeechAndTtsManager
import com.example.util.SystemCommandHelper
import com.example.util.VoiceState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MainUiState(
    val isLoading: Boolean = false,
    val statusMessage: String = "JARVIS ONLINE",
    val errorMessage: String? = null,
    val showApiKeyPrompt: Boolean = false,
    val isTextModeInput: Boolean = false
)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val chatDao = db.chatDao()
    val settingsRepo = SettingsRepository(application)
    private val geminiRepo = GeminiRepository()
    private val commandHelper = SystemCommandHelper(application)

    val chatHistory: StateFlow<List<ChatMessageEntity>> = chatDao.getAllMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customApiKey: StateFlow<String> = settingsRepo.customApiKey
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    val autoSpeak: StateFlow<Boolean> = settingsRepo.autoSpeak
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val speechRate: StateFlow<Float> = settingsRepo.speechRate
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1.0f)

    val speechPitch: StateFlow<Float> = settingsRepo.speechPitch
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.95f)

    val systemPrompt: StateFlow<String> = settingsRepo.systemPrompt
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), com.example.data.preferences.DEFAULT_SYSTEM_PROMPT)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _fallbackReplayState = MutableStateFlow(ReplayState())
    var speechAndTtsManager: SpeechAndTtsManager? = null

    val replayState: StateFlow<ReplayState>
        get() = speechAndTtsManager?.replayState ?: _fallbackReplayState.asStateFlow()

    init {
        // Welcome message shown ONLY ONCE on initial installation guard
        viewModelScope.launch {
            val isSeeded = settingsRepo.initialGreetingSeeded.first()
            if (!isSeeded) {
                settingsRepo.setInitialGreetingSeeded(true)
                if (chatDao.getMessageCount() == 0) {
                    chatDao.insertMessage(
                        ChatMessageEntity(
                            sender = MessageSender.JARVIS,
                            text = "Good day, Sir. J.A.R.V.I.S. system core online. How may I assist you today?"
                        )
                    )
                }
            }
        }
    }

    fun initSpeechManager(manager: SpeechAndTtsManager) {
        this.speechAndTtsManager = manager
        viewModelScope.launch {
            manager.voiceState.collect { state ->
                when (state) {
                    is VoiceState.Error -> {
                        android.util.Log.e("JARVIS_LOG", "Voice error observed: ${state.message}")
                        _uiState.value = _uiState.value.copy(
                            errorMessage = state.message,
                            statusMessage = "VOICE CORE ALERT"
                        )
                    }
                    is VoiceState.Listening -> {
                        _uiState.value = _uiState.value.copy(statusMessage = "LISTENING...")
                    }
                    is VoiceState.Processing -> {
                        _uiState.value = _uiState.value.copy(statusMessage = "TRANSCRIBING VOICE...")
                    }
                    is VoiceState.Speaking -> {
                        _uiState.value = _uiState.value.copy(statusMessage = "JARVIS VOCALIZING")
                    }
                    is VoiceState.Idle -> {
                        if (!_uiState.value.isLoading) {
                            _uiState.value = _uiState.value.copy(statusMessage = "JARVIS ONLINE")
                        }
                    }
                }
            }
        }
        viewModelScope.launch {
            manager.replayState.collect { rState ->
                when (rState.status) {
                    ReplayStatus.PLAYING -> {
                        _uiState.value = _uiState.value.copy(statusMessage = "PLAYING...")
                    }
                    ReplayStatus.READY -> {
                        if (!_uiState.value.isLoading) {
                            _uiState.value = _uiState.value.copy(statusMessage = "READY")
                        }
                    }
                    ReplayStatus.ERROR -> {
                        _uiState.value = _uiState.value.copy(
                            statusMessage = "TTS ERROR",
                            errorMessage = "Replay failed for message"
                        )
                    }
                }
            }
        }
    }

    fun processUserInput(input: String, isVoiceInput: Boolean = false) {
        if (input.isBlank()) return

        val userMessage = input.trim()
        android.util.Log.d("JARVIS_LOG", "processUserInput triggered (isVoiceInput=$isVoiceInput): '$userMessage'")
        
        viewModelScope.launch {
            // Save user message to database
            chatDao.insertMessage(
                ChatMessageEntity(
                    sender = MessageSender.USER,
                    text = userMessage,
                    isVoiceMessage = isVoiceInput
                )
            )

            // Step 1: Check if this is a direct system command
            val commandResult = commandHelper.executeOrParseCommand(userMessage)
            if (commandResult is CommandExecutionResult.Executed) {
                android.util.Log.d("JARVIS_LOG", "Executed system command: ${commandResult.actionName}")
                // Save system execution response
                chatDao.insertMessage(
                    ChatMessageEntity(
                        sender = MessageSender.JARVIS,
                        text = commandResult.confirmationMessage,
                        executedCommand = commandResult.actionName
                    )
                )
                if (autoSpeak.value || isVoiceInput) {
                    android.util.Log.d("JARVIS_LOG", "TTS starting for command confirmation")
                    speechAndTtsManager?.speak(
                        commandResult.confirmationMessage,
                        rate = speechRate.value,
                        pitch = speechPitch.value
                    )
                }
                return@launch
            }

            // Step 2: Pass to Gemini AI if not a system command or if it was a search/query
            _uiState.value = _uiState.value.copy(
                isLoading = true,
                statusMessage = "PROCESSING CORE MATRIX...",
                errorMessage = null
            )

            val currentHistory = chatHistory.value
            val currentApiKey = customApiKey.value
            val currentPrompt = systemPrompt.value

            when (val geminiResult = geminiRepo.generateReply(currentHistory, userMessage, currentApiKey, currentPrompt)) {
                is GeminiResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        statusMessage = "JARVIS ONLINE"
                    )
                    chatDao.insertMessage(
                        ChatMessageEntity(
                            sender = MessageSender.JARVIS,
                            text = geminiResult.responseText
                        )
                    )
                    if (autoSpeak.value || isVoiceInput) {
                        android.util.Log.d("JARVIS_LOG", "TTS starting for Gemini response")
                        speechAndTtsManager?.speak(
                            geminiResult.responseText,
                            rate = speechRate.value,
                            pitch = speechPitch.value
                        )
                    }
                }
                is GeminiResult.Error -> {
                    android.util.Log.e("JARVIS_LOG", "Gemini request error: ${geminiResult.message}")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        statusMessage = "CORE ALERT",
                        errorMessage = geminiResult.message
                    )
                    val errorText = "Diagnostic alert: ${geminiResult.message}"
                    chatDao.insertMessage(
                        ChatMessageEntity(
                            sender = MessageSender.JARVIS,
                            text = errorText
                        )
                    )
                    if (autoSpeak.value || isVoiceInput) {
                        speechAndTtsManager?.speak(
                            errorText,
                            rate = speechRate.value,
                            pitch = speechPitch.value
                        )
                    }
                }
            }
        }
    }

    fun replayMessage(message: ChatMessageEntity) {
        if (speechAndTtsManager == null) {
            setError("TextToSpeech service is not initialized.")
            return
        }
        speechAndTtsManager?.replayMessage(
            messageId = message.id,
            text = message.text,
            rate = speechRate.value,
            pitch = speechPitch.value
        )
    }

    fun speakText(text: String) {
        speechAndTtsManager?.speak(text, rate = speechRate.value, pitch = speechPitch.value)
    }

    fun stopSpeaking() {
        speechAndTtsManager?.stopSpeaking()
    }

    fun toggleTextModeInput() {
        _uiState.value = _uiState.value.copy(isTextModeInput = !_uiState.value.isTextModeInput)
    }

    fun clearHistory() {
        viewModelScope.launch {
            chatDao.clearHistory()
            chatDao.insertMessage(
                ChatMessageEntity(
                    sender = MessageSender.JARVIS,
                    text = "System chat logs purged. All systems operating nominally, Sir."
                )
            )
        }
    }

    fun saveApiKey(key: String) {
        viewModelScope.launch {
            settingsRepo.setCustomApiKey(key)
        }
    }

    fun saveAutoSpeak(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.setAutoSpeak(enabled)
        }
    }

    fun saveSpeechRate(rate: Float) {
        viewModelScope.launch {
            settingsRepo.setSpeechRate(rate)
        }
    }

    fun saveSpeechPitch(pitch: Float) {
        viewModelScope.launch {
            settingsRepo.setSpeechPitch(pitch)
        }
    }

    fun saveSystemPrompt(prompt: String) {
        viewModelScope.launch {
            settingsRepo.setSystemPrompt(prompt)
        }
    }

    fun setError(msg: String) {
        android.util.Log.e("JARVIS_LOG", "error: $msg")
        _uiState.value = _uiState.value.copy(errorMessage = msg, statusMessage = "CORE ALERT")
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null, statusMessage = "JARVIS ONLINE")
    }
}

class JarvisViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(JarvisViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return JarvisViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
