package com.example.ui.screens

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.JarvisViewModel
import com.example.ui.components.ArcReactorCore
import com.example.ui.components.ChatMessageList
import com.example.ui.components.CommandMenuDialog
import com.example.ui.components.JarvisBottomBar
import com.example.ui.components.JarvisHeader
import com.example.ui.theme.JarvisError
import com.example.ui.theme.JarvisGold
import com.example.util.ReplayState
import com.example.util.VoiceState
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.launch

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun MainScreen(
    viewModel: JarvisViewModel,
    onOpenSettings: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val chatHistory by viewModel.chatHistory.collectAsState()
    val voiceState = viewModel.speechAndTtsManager?.voiceState?.collectAsState()?.value ?: VoiceState.Idle
    val replayState by viewModel.replayState.collectAsState()

    val recordAudioPermissionState = rememberPermissionState(Manifest.permission.RECORD_AUDIO)
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var showCommandMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            JarvisHeader(
                statusText = uiState.statusMessage,
                onOpenSettings = onOpenSettings
            )
        },
        bottomBar = {
            JarvisBottomBar(
                isTextModeInput = uiState.isTextModeInput,
                onToggleTextMode = { viewModel.toggleTextModeInput() },
                onSendText = { text ->
                    viewModel.processUserInput(text, isVoiceInput = false)
                },
                onClearHistory = { viewModel.clearHistory() },
                onOpenCommandMenu = { showCommandMenu = true }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color(0xFF020408)
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Error Diagnostic Banner
            if (!uiState.errorMessage.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(JarvisError.copy(alpha = 0.2f))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Alert",
                            tint = JarvisError,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = uiState.errorMessage!!,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { viewModel.clearError() }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss",
                                tint = Color.White
                            )
                        }
                    }
                }
            }

            // Hero Arc Reactor Core Center Node
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                ArcReactorCore(
                    voiceState = voiceState,
                    isLoading = uiState.isLoading,
                    onMicClick = {
                        android.util.Log.d("JARVIS_LOG", "MIC BUTTON CLICKED")
                        if (recordAudioPermissionState.status.isGranted) {
                            if (voiceState is VoiceState.Listening) {
                                viewModel.speechAndTtsManager?.stopListening()
                            } else if (voiceState is VoiceState.Speaking) {
                                viewModel.speechAndTtsManager?.stopSpeaking()
                            } else {
                                android.util.Log.d("JARVIS_LOG", "SPEECH RECOGNITION STARTED")
                                val isAvail = viewModel.speechAndTtsManager?.isSpeechAvailable() ?: false
                                if (isAvail) {
                                    viewModel.speechAndTtsManager?.startListening()
                                } else {
                                    viewModel.setError("Speech recognition service unavailable on this device/browser environment.")
                                }
                            }
                        } else {
                            android.util.Log.d("JARVIS_LOG", "MICROPHONE PERMISSION REQUESTED")
                            recordAudioPermissionState.launchPermissionRequest()
                            viewModel.setError("Microphone permission requested. Please grant access to speak with JARVIS.")
                        }
                    }
                )
            }

            // Scrollable Chat Message History Stream
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                ChatMessageList(
                    messages = chatHistory,
                    replayState = replayState,
                    onReplayMessage = { message -> viewModel.replayMessage(message) }
                )
            }
        }
    }

    // Quick System Command Sheet Dialog
    if (showCommandMenu) {
        CommandMenuDialog(
            onDismiss = { showCommandMenu = false },
            onExecuteCommand = { command ->
                viewModel.processUserInput(command, isVoiceInput = false)
            }
        )
    }
}
