package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.remote.GeminiRepository
import com.example.data.remote.GeminiResult
import com.example.ui.JarvisViewModel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("JARVIS", appName)
  }

  @Test
  fun `test voice command pipeline with Hello JARVIS`() = runBlocking {
    val repo = GeminiRepository()
    val result = repo.generateReply(
      history = emptyList(),
      userMessage = "Hello JARVIS, how are you?",
      customApiKey = "",
      systemPrompt = "You are JARVIS."
    )
    assertTrue("Result should be non-null", result is GeminiResult.Success || result is GeminiResult.Error)
    if (result is GeminiResult.Success) {
      assertTrue("Response text should be non-blank", result.responseText.isNotBlank())
    }
  }

  @Test
  fun `test mic button tap interaction`() {
    var micClicked = false
    val onMicClick = { micClicked = true }
    onMicClick()
    assertTrue("Microphone button click handler must execute immediately", micClicked)
  }

  @Test
  fun `test replay button tap triggers playback exactly once`() {
    var playCount = 0
    val sampleMessage = com.example.data.local.ChatMessageEntity(
      id = 101L,
      sender = com.example.data.local.MessageSender.JARVIS,
      text = "All systems operational, Sir."
    )

    val onReplay: (com.example.data.local.ChatMessageEntity) -> Unit = { msg ->
      if (msg.id == 101L) {
        playCount++
      }
    }

    onReplay(sampleMessage)
    assertEquals("Playback should be triggered exactly once", 1, playCount)
  }
}
